package eu.tutorials.designershoeshock

import eu.tutorials.designershoeshock.model.ProductModel


data class CartItem(var product: ProductModel, var quantity: Int = 0)