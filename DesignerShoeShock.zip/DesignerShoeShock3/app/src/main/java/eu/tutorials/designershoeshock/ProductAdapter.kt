package eu.tutorials.designershoeshock


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import eu.tutorials.designershoeshock.databinding.ItemProductBinding
import eu.tutorials.designershoeshock.model.ProductModel

class ProductAdapter(

    private val products: List<ProductModel>,
    private val fabToCart: (ProductModel) -> Unit,


    ) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemProductBinding.inflate(layoutInflater, parent, false)
        return ProductViewHolder(binding, fabToCart)
    }
    override fun getItemCount(): Int = products.size

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val products = products[position]
        holder.bind(products)
        holder.itemView.setOnClickListener {


        }
    }
     class ProductViewHolder(
        private val binding: ItemProductBinding, private val fabToCart: (ProductModel) -> Unit,
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(product: ProductModel) {
            binding.apply {
                productBackgroundImage.setImageResource(product.image)
                productShoeName.text = product.name
                productSubtitle.text = product.subTitle
                productPrice.text = product.price
                fabToCart.setOnClickListener {
                    fabToCart(product)
                }


            }
        }

    }


}




