package eu.tutorials.designershoeshock

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import eu.tutorials.designershoeshock.databinding.ActivityCategoryBinding
import eu.tutorials.designershoeshock.repository.DesignerShoeShockRepository

class CategoryActivity : AppCompatActivity() {

    companion object {
        const val CATEGORY = "CATEGORY"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityCategoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        val category = intent.getStringExtra(CATEGORY).orEmpty()

        val products = DesignerShoeShockRepository.getProduct(category)

        Log.v("CategoryActivity", "category = $category")

        binding.productListRcyViw.apply {
            adapter = ProductAdapter(products){
                productModel ->
                val intent = Intent(this@CategoryActivity, ProductAdapter::class.java)
                intent.putExtra(CategoryActivity.CATEGORY, productModel.image)
                startActivity(intent)


            }
            layoutManager = GridLayoutManager(this@CategoryActivity, 1)
            setHasFixedSize(true)
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home){
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}