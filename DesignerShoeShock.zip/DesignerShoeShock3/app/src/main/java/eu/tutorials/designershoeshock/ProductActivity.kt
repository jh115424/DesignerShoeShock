package eu.tutorials.designershoeshock
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.snackbar.Snackbar
import eu.tutorials.designershoeshock.databinding.ActivityCartBinding
import eu.tutorials.designershoeshock.repository.CartRepository

import eu.tutorials.designershoeshock.repository.DesignerShoeShockRepository

class ProductActivity : AppCompatActivity() {


    companion object {
        const val PRODUCT = "PRODUCT"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        val category = intent.getStringExtra(PRODUCT).orEmpty()
        val products = DesignerShoeShockRepository.getProduct(category)

        Log.v("ProductActivity", "product = $products")

        binding.cartListRcyViw.apply {

            adapter = ProductAdapter(products){

                Log.v("ProductActivity", "product = $it")

            }

            layoutManager = GridLayoutManager(this@ProductActivity, 1)
            setHasFixedSize(true)
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}











