package eu.tutorials.designershoeshock.model

data class CategoryModel(

    val title: String,
    val image: Int,
)