package eu.tutorials.designershoeshock

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import eu.tutorials.designershoeshock.databinding.ActivityMainBinding


import eu.tutorials.designershoeshock.model.ProductModel
import eu.tutorials.designershoeshock.repository.DesignerShoeShockRepository

class MainActivity : AppCompatActivity() {



    private var products = ArrayList<ProductModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)


        setContentView(binding.root)


        binding.categoryList.apply {
            adapter = CategoryAdapter(
                DesignerShoeShockRepository.getCategories()
            ) {categoryModel ->
                val intent = Intent(this@MainActivity, CategoryActivity::class.java)
                intent.putExtra(CategoryActivity.CATEGORY, categoryModel.title)
                startActivity(intent)
            }
            layoutManager = LinearLayoutManager(this@MainActivity)
            setHasFixedSize(true)
        }
    }

}