package eu.tutorials.designershoeshock

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import eu.tutorials.designershoeshock.databinding.ItemPurchaseBinding
import org.w3c.dom.Text

class PurchaseActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.item_purchase)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val textView: TextView =findViewById(R.id.PurchaseTextView)
        Toast.makeText(this, "Purchase Complete!", Toast.LENGTH_SHORT)
            .show()

    }

}