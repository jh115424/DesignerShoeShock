package eu.tutorials.designershoeshock


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import eu.tutorials.designershoeshock.databinding.ItemCategoryBinding
import eu.tutorials.designershoeshock.model.CategoryModel
import eu.tutorials.designershoeshock.model.ProductModel

class CategoryAdapter(
    private val categories: List<CategoryModel>,
    private val onClick: (CategoryModel) -> Unit,


) : RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {

        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemCategoryBinding.inflate(layoutInflater, parent, false)
        return CategoryViewHolder(binding)
    }
    override fun getItemCount() = categories.size

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        val category = categories[position]
        holder.bind(category)
        holder.itemView.setOnClickListener {
            onClick(category)
        }
    }
    class CategoryViewHolder(
        private val binding: ItemCategoryBinding,
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(category: CategoryModel) {
            binding.apply {
               categoryBackgroundImage.setImageResource(category.image)
                categoryShoeName.text = category.title


                }
            }
        }
    }



