package eu.tutorials.designershoeshock.model

data class ProductModel(
    val name: String,
    val subTitle: String,
    val price: String,
    val image: Int,

)
