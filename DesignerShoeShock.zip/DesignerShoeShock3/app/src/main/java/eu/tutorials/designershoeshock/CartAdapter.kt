package eu.tutorials.designershoeshock

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import eu.tutorials.designershoeshock.databinding.ItemCartBinding
import eu.tutorials.designershoeshock.model.ProductModel

class CartAdapter(private val products: List<ProductModel>,
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemCartBinding.inflate(layoutInflater, parent, false)
        return CartViewHolder(binding)
    }

    override fun getItemCount() = products.size

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val product = products[position]
        holder.bind(product)
        holder.itemView.setOnClickListener {  }
        holder.itemView.setOnClickListener {  }
        holder.itemView.setOnClickListener {  }
        holder.itemView.setOnClickListener {  }
    }
    class CartViewHolder(
        private val binding: ItemCartBinding
    ) : RecyclerView.ViewHolder(binding.root){

        fun bind(product: ProductModel){
            binding.apply {
                addShoe.setOnClickListener {
                    addShoe
                }
                subtractShoe.setOnClickListener {
                    subtractShoe
                }
                textCounter.text = textCounter.text

                CartButton.setOnClickListener {
                    CartButton
                }
            }
        }

    }

}

