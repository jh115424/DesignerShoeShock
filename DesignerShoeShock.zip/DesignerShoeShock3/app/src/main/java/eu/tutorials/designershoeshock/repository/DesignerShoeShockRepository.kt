package eu.tutorials.designershoeshock.repository

import eu.tutorials.designershoeshock.R
import eu.tutorials.designershoeshock.model.CategoryModel
import eu.tutorials.designershoeshock.model.ProductModel


object DesignerShoeShockRepository {

    private val categories = listOf(

        CategoryModel("Boots", R.drawable.lady_boot),
        CategoryModel("Heels", R.drawable.lady_heel),
        CategoryModel("Flats", R.drawable.lady_flat),
        CategoryModel("Sneakers", R.drawable.sneakers5)

    )
    private final var boots = listOf(
        ProductModel("Prada", "Black Leather Logo", "$850", R.drawable.boot),
        ProductModel("Michael Kors", "Blue Denim", "$185", R.drawable.boot2),
        ProductModel("Dolce & Gabbana", "", "$700", R.drawable.boots4),
        ProductModel("Gucci", "", "$1100", R.drawable.boots3)
    )
    private var heels = listOf(
        ProductModel("Coach", "", "$365", R.drawable.heels),
        ProductModel("Christian Louboutin", "", "$425", R.drawable.heels2),
        ProductModel("Prada", "", "$450", R.drawable.heels3),
        ProductModel("Gucci", "", "$300", R.drawable.heels4),
    )
    private var flats = listOf(
        ProductModel("Coach", "", "$225", R.drawable.flats),
        ProductModel("Gucci", "", "$625", R.drawable.flats2),
        ProductModel("Michael Kors", "", "$185", R.drawable.flats3),
        ProductModel("Christian Louboutin", "", "$425", R.drawable.flats4)
    )
    private var sneakers = listOf(
        ProductModel("Gucci", "", "$450", R.drawable.sneakers),
        ProductModel("Michael Kors", "", "$185", R.drawable.sneakers2),
        ProductModel("Christian Dior", "", "$800", R.drawable.sneakers3),
        ProductModel("Dolce & Gabbana", "", "$510", R.drawable.sneakers4)


    )
    private val empty = emptyList<ProductModel>()


    fun getCategories() = categories


    fun getProduct(category: String): List<ProductModel>{
        return when(category){
            "Boots" -> boots
            "Heels" -> heels
            "Flats" -> flats
            "Sneakers" -> sneakers

            else -> emptyList()
        }
    }
}
