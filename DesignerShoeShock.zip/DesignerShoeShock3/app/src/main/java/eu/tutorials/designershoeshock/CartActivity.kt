package eu.tutorials.designershoeshock

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import eu.tutorials.designershoeshock.databinding.ItemCartBinding
import eu.tutorials.designershoeshock.repository.CartRepository


class CartActivity : AppCompatActivity() {

    companion object {

        const val CART = "CART"
    }

    lateinit var adapter: CartAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ItemCartBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val intent = Intent(this@CartActivity, PurchaseActivity::class.java)
        startActivity(intent)

    }

    private val cartItem = mutableMapOf<String, Int>()


    fun addShoeToCart(product: String) {

        cartItem[product] = cartItem[product]?.plus(1) ?: 0

        val cart = CartRepository.getProduct(String())

        val shoeItem = cart.plus(1)

        if (shoeItem == Any()) {
            shoeItem.plus(1)
        } else
            shoeItem.toString()

        CartActivity.CART

    }

    fun subtractShoeFromCart(product: String) {

        cartItem[product] = cartItem[product]?.minus(1) ?: 0

        val cart = CartRepository.getProduct(String())

        val shoeItem = cart.minus(1)

        if (shoeItem == Any()) {
            shoeItem.minus(1)
        } else
            shoeItem.toString()

        CartActivity.CART
    }



    override fun getLayoutInflater(): LayoutInflater {
        return super.getLayoutInflater()

    }
}

        //private val cart = mutableMapOf<String, Int>()

    //fun addShoeToCart(product: String) {

        //cart[product] = cart[product]?.plus(1) ?: 0

        //if(addShoeToCart())

        //val shoeItem = cart.equals(1)

    //}

    //fun removeShoeFromCart(product: String){

        //cart[product] = cart[product]?.minus(1)?: 0

        //val shoeItem = cart.equals(1)
    //}






    //fun addShoeToCart(product: String){
        //cart[product] = cart[product]?.plus(1)?: 0

        //val shoeItem = cart.equals(1)


    //}
    //fun removeShoeFromCart(product: String){
        //cart[product] = cart[product]?.minus(1)?: 0
    //}



//}